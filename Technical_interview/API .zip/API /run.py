from api import app

BASE = "http://127.0.0.1:5000/ "

# response = requests.get(BASE + 'cars')
# print(response.json())

app.run()